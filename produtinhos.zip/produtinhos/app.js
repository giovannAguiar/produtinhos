const express = require('express');
const bodyParser = require('body-parser');
const prodController = require('./controllers/relatorioProdController');
const app = express();

// Configura o EJS como mecanismo de visualização
app.set('view engine', 'ejs');

// Middleware para parsing do body
app.use(bodyParser.urlencoded({ extended: false }));

app.get('/', prodController.getAllProds);

app.get('/relatorio/pdf', prodController.generatePDF);

// Iniciar o servidor
app.listen(2000, () => {
    console.log('Servidor rodando na porta 2000');
});
